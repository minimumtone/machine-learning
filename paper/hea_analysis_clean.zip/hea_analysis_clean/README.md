# HEA Lattice Constant Prediction — Clean Re-analysis

## Overview
Structure-specific DFT volume size factors (Ω_sf) for HEA lattice constant prediction.
Element-level additive decomposition: Ω_sf(i-j) ≈ δ_i^(s) + δ_j^(s).

## Data (Gd/Ce excluded throughout)
- MP: 1,002 compounds, OQMD: 2,295 compounds, VASP: 3,969 compounds (total: 7,266)
- B2 pairwise Ω_sf: 152 pairs, L1₂ pairwise Ω_sf: 95 pairs
- Additive decomposition: 38 elements (36 B2, 33 L1₂)

## Key Results
- Training (64 HEA): Pairwise RMSE = 0.0210 Å, Additive RMSE = 0.0211 Å
- Independent test (20 HEA): Pairwise RMSE = 0.0200 Å
- γ_BCC = 1.4517, γ_FCC = 1.0824 (pairwise)
- Additive R²: B2 = 0.61, L1₂ = 0.69

## Reproduction
```bash
cd /path/to/machine-learning
python paper/generate_all_figures.py
```
Requires: numpy, pandas, scipy, matplotlib, and hea_lattice_xgboost.py in repo root.

## Files
- `analysis_code/generate_all_figures.py` — Master analysis script
- `data/results_delta_parameters.csv` — 38 elements with δ^(B2) and δ^(L1₂)
- `data/results_omega_sf.csv` — 247 pairwise Ω_sf values
- `data/results_independent_test.csv` — 20 independent test HEA predictions
- `figures/` — 16 publication-quality PNG figures
